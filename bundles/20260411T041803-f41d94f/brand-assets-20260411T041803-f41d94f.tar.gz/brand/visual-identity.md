# Visual Identity

_Human-readable source of truth for brand colors, typography, assets, and token ownership._

## Colors

| Name | Hex |
|---|---|
| Charcoal | `#111b1e` |
| Navy | `#1b263b` |
| Brown | `#91705a` |

## Typography

Machine tokens live in `tokens/typography.json`.

**Font:** Anonymous Pro

| Element | Size | Weight |
|---|---|---|
| H1 | 64px | 700 |
| H2 | 52px | 700 |
| Body | 44px | 400 |

## Post Variants

Machine tokens live in `tokens/visual-variants.json`.

| Key | Description |
|---|---|
| `white` | White background |
| `dark` | Charcoal background |
| `blue` | Navy background |
| `brown` | Brown background |

## Copy Constraints (Instagram)

Machine tokens live in `tokens/captions.json`.

- Headline: max 80 characters
- Body: max 180 characters
- CTA: max 60 characters
- Hashtags: 3–5, lowercase
