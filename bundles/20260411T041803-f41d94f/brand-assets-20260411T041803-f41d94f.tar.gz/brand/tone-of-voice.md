# Tone of Voice

_Human-readable source of truth for all Tucker Whit / ATW brand voice. Projects reference this file — do not maintain copies._

## Core Voice

- **Direct but not harsh.** Get to the point fast. No throat-clearing, no wind-up paragraphs.
- **Intellectually sharp without being academic.** Bring the insight, not the credentials.
- **Warm and grounded.** Relatable to real people doing real work — faith, life, ministry, craft.
- **Dry wit, occasionally sarcastic — earned, not performed.** If a line is funny, let it land. Don't reach for it.
- **Confident without being preachy.** Never over-spiritual. Never lecture the reader.

## What to Avoid

- No hype. No urgency language ("don't miss this," "game-changer," etc.)
- No corporate speak. No jargon, no buzzwords, no thought-leadership voice.
- No inspirational filler. Every sentence earns its place.
- No superlatives. Don't tell people something is amazing — show them why it matters.
- No em dashes in internal/EA communication or lesson plan copy. In newsletter drafts and episode content, em dashes are fine — but never with spaces around them. Use — not  —  .
- No softening. Do not sand down his edges to make content feel safer or more palatable.
- No filler affirmations ("Great question," "Absolutely," etc.)

## By Context

### Internal (EA, tools, pipelines)

Casual, direct, bullet points over paragraphs. Minimal preamble. Assume David already knows the context — skip the recap, get to the action or finding. Tone is peer-to-peer, not assistant-to-boss.

### External / ATW Audience (Marcus — Driven Believer)

Warm, grounded, practical. This person is serious about their faith and their life — they don't need to be sold on growth, they need real substance. Write like you're talking to someone at 6 AM who actually wants to be there. No performance, no hype. Would Marcus feel seen, or does this sound like a podcast ad?

### External / Ministry Leaders (Pastor James — Called Leader)

Respects complexity. Pastors deal with real operational and spiritual weight — treat them as intelligent adults navigating hard things. Position is trusted advisor, not consultant. Never preachy, never condescending. Bring the clarity they don't have time to develop themselves, and let that be enough.

### Post Copy (Instagram)

Warm, grounded, thoughtful. Short and precise — nothing wasted. No urgency language, no superlatives, no filler affirmations. Copy should feel like a calm, considered thought — not a push notification. Hashtags lowercase, 3–5, no branded tags.

## Character Notes

- Structural markers like **Hard Truth** and **Bottom Line** are used deliberately as formatting tools — they signal a shift in register, not decoration. Use them only where the content earns it.
- Dry wit is part of the voice, not a layer added on top. If the wit is visible, it's probably too much.
- Faith is present but never performative. David writes as someone for whom faith is the operating system, not a product feature.
- The voice holds tension well — direct and warm, sharp and accessible, confident and grounded. Don't flatten it in either direction.
