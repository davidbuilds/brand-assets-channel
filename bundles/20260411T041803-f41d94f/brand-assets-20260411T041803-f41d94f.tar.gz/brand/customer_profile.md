# Moved — canonical source: /Users/dtw/Documents/Workhub/brain/sources/icp/atw-profiles.md

This legacy brand-facing path remains only as a compatibility stub.
