# David's POV: Wealth, Ministry, and Prosperity Gospel

This document encodes David's theological position on wealth and ministry for use in
op-ed draft generation. It is not a comprehensive theology — it is a working POV
that informs how op-eds engage with these topics. Update it as the position develops.

---

## Core Position

Wealth pursued and maintained under godly direction is good. The dominion mandate
(Genesis 1:26-28) is not revoked — Christians are called to steward resources, build
things, and create value in the world. This connects directly to the seven mountains
mandate: believers are called to occupy and influence the seven spheres of culture
(government, education, media, arts, business, family, religion). Financial capacity
is essential to that mission. You cannot influence what you cannot sustain.

Financial strength is not a spiritual liability. It is a tool. What matters is the
operating system: is this built under God's direction, or is it self-serving under
a religious veneer?

Prosperity gospel is something different and worse. It is not a theology of wealth —
it is a transaction theology. Sow a seed to this ministry and God will multiply your
return. That framework is corrupt because it inverts the relationship between faith
and outcome, exploits vulnerable people's genuine desire for God's blessing, and
insulates its practitioners from accountability by framing criticism as spiritual attack.

The critique of prosperity gospel is not anti-wealth. It is anti-exploitation.

---

## The Operational Angle

This is where the ICP lens matters.

For Marcus (lay minister, building): the question is whether his financial life is
being built under calling or under pressure. Ministry often creates financial strain
that tempts people toward either resentment or magical thinking. The grounded
alternative is: do the work, build with integrity, trust God with the outcome.
Financial sustainability in ministry is a stewardship question, not a faith question.
The seven mountains frame is also personal for Marcus — he is occupying his mountain
whether he names it that way or not. His financial life funds that presence.

For Pastor James (church leader): the question is what the church is modeling from
the pulpit and in its revenue structure. A church that talks about giving primarily
in terms of what donors will receive is running prosperity gospel logic whether it
intends to or not. A church that builds transparent, diversified revenue (tithes,
programs, events, partnerships) and communicates about money with honesty is modeling
the stewardship ethic it preaches. The church itself occupies the religion mountain —
and how it handles money shapes its credibility in every other sphere.

---

## What to Engage, What to Avoid

Engage:
- The structural incentives that make prosperity gospel persist (pastors need revenue,
  donors want certainty, the transaction frame is emotionally satisfying)
- The genuine theological question of whether God blesses obedience materially —
  the answer is nuanced, not a flat no
- The operational reality of building financial sustainability in ministry and church
- The seven mountains mandate as a framework for why financial capacity matters
- High-profile cases where the gap between preached theology and lived behavior is
  documentable

Avoid:
- Sardonic takedowns that read as cultural commentary without theological substance
- Treating all charismatic or Word of Faith theology as equivalent to prosperity gospel
- Implying that struggling financially means lacking faith, or that wealth always
  signals blessing
- Preaching — make the argument and let it stand

---

## Key Scriptures

- Luke 12:42-48 — the faithful manager; stewardship requires agency, not passivity
- Genesis 1:26-28 — the dominion mandate; the original commission to occupy and build
- 1 Timothy 6:6-10, 17-19 — godliness with contentment vs. love of money; nuanced,
  not anti-wealth
- Matthew 6:24 — cannot serve two masters; the operating system question
- Luke 16:10-13 — faithful in little, faithful in much; stewardship scales
- Matthew 5:13-16 — salt and light; presence and influence in culture
